//
//  GymExercise.swift
//  GymApp
//
//  Created by Xcode on 12/9/24.
//

import Foundation

// Difficulty Levels
enum DifficultyLevel: String, Codable, CaseIterable {
    case Beginner, Intermediate, Advanced
}

// Exercise Model
struct GymExercise: Identifiable, Codable, Equatable {
    var id: UUID // Make id mutable
        var name: String
        var description: String
        var imageName: String
        var instructions: String
        var caloriesPerMinute: Int
        var difficulty: DifficultyLevel

        // Provide a default initializer
        init(id: UUID = UUID(), name: String, description: String, imageName: String, instructions: String, caloriesPerMinute: Int, difficulty: DifficultyLevel) {
            self.id = id
            self.name = name
            self.description = description
            self.imageName = imageName
            self.instructions = instructions
            self.caloriesPerMinute = caloriesPerMinute
            self.difficulty = difficulty
    }
}

// Exercise Session Model
struct ExerciseSession: Codable, Identifiable {
    let id: UUID
    let exerciseName: String
    let duration: Int
    let caloriesBurnt: Int
    let date: Date
}
