//
//  ExerciseView.swift
//  GymApp
//
//  Created by Xcode on 12/9/24.
//

import SwiftUI

struct ExerciseView: View {
    @StateObject private var viewModel = ExerciseViewModel()
    @State private var newCalorieGoal: String = "" // Input for a new goal
    @FocusState private var isGoalInputFocused: Bool // Keyboard focus state

    var body: some View {
        NavigationView {
            ZStack {
                // Background Gradient
                LinearGradient(gradient: Gradient(colors: [Color.blue.opacity(0.3), Color.white]),
                               startPoint: .topLeading,
                               endPoint: .bottomTrailing)
                    .ignoresSafeArea()

                VStack(spacing: 20) {
                    // Title Header
                    Text("Gym Exercises")
                        .font(.largeTitle)
                        .fontWeight(.heavy)
                        .foregroundColor(.blue)

                    // Calorie Goal Section
                    VStack(spacing: 12) {
                        Text("Calorie Goal Progress")
                            .font(.title2)
                            .foregroundColor(.blue)

                        ProgressView(
                            value: Double(min(viewModel.totalCaloriesBurnt, viewModel.calorieGoal)),
                            total: Double(max(viewModel.calorieGoal, 1))
                        )
                        .progressViewStyle(LinearProgressViewStyle(tint: .blue))
                        .padding(.horizontal)
                        .scaleEffect(1.2)

                        Text("Calories Burnt: \(viewModel.totalCaloriesBurnt) / \(viewModel.calorieGoal) kcal")
                            .font(.headline)
                            .foregroundColor(.black)
                    }
                    .padding()
                    .background(RoundedRectangle(cornerRadius: 12)
                        .fill(Color.white)
                        .shadow(color: .gray.opacity(0.4), radius: 4, x: 0, y: 2))

                    // Compact Button Layout
                    HStack(spacing: 12) {
                        // TextField and Save Button
                        HStack {
                            TextField("New Goal", text: $newCalorieGoal)
                                .keyboardType(.numberPad)
                                .textFieldStyle(RoundedBorderTextFieldStyle())
                                .frame(width: 120)
                                .focused($isGoalInputFocused)

                            Button(action: {
                                isGoalInputFocused = false
                                if let goal = Int(newCalorieGoal), goal > 0 {
                                    viewModel.setCalorieGoal(goal)
                                    newCalorieGoal = ""
                                }
                            }) {
                                Image(systemName: "checkmark.circle")
                                    .foregroundColor(.white)
                                    .padding(8)
                                    .background(Color.green)
                                    .clipShape(Circle())
                                    .shadow(radius: 2)
                            }
                        }

                        // Reset Button
                        Button(action: {
                            isGoalInputFocused = false
                            viewModel.resetGoalToZero()
                        }) {
                            HStack {
                                Image(systemName: "arrow.counterclockwise")
                                    .foregroundColor(.red)
                            }
                            .padding(8)
                            .background(RoundedRectangle(cornerRadius: 8)
                                .stroke(Color.red, lineWidth: 1.5))
                        }

                        // Favorites Button
                        NavigationLink(destination: FavoritesView(viewModel: viewModel)) {
                            HStack {
                                Image(systemName: "heart.fill")
                                    .foregroundColor(.orange)
                            }
                            .padding(8)
                            .background(RoundedRectangle(cornerRadius: 8)
                                .stroke(Color.orange, lineWidth: 1.5))
                        }
                    }

                    // Exercises List
                    ScrollView {
                        LazyVStack(spacing: 16) {
                            ForEach(viewModel.allExercises) { exercise in
                                NavigationLink(destination: ExerciseDetailView(exercise: exercise, viewModel: viewModel)) {
                                    ExerciseCard(
                                        exercise: exercise,
                                        isFavorite: viewModel.isFavorite(exercise),
                                        onFavoriteToggle: { viewModel.toggleFavorite(exercise) }
                                    )
                                    
                                
                                    .padding(.horizontal)
                                }
                            }
                        }
                    }
                }
                .padding()
            }
            //.navigationTitle("Gym Exercises")
            .onTapGesture {
                isGoalInputFocused = false // Dismiss keyboard when tapping outside
            }
        }
    }
}

#Preview {
    ExerciseView()
}
