//
//  ExerciseDetailView.swift
//  GymApp
//
//  Created by Xcode on 12/9/24.
//



import SwiftUI

struct ExerciseDetailView: View {
    let exercise: GymExercise
    @ObservedObject var viewModel: ExerciseViewModel

    @State private var duration: String = ""
    @FocusState private var isTextFieldFocused: Bool

    @State private var timeRemaining: Int = 0
    @State private var elapsedTime: Int = 0
    @State private var timerRunning = false
    @State private var isPaused = false
    @State private var timer: Timer?
    @State private var canLogExercise = false
    @State private var showCompletionAlert = false

    var body: some View {
        ZStack {
            // Background Gradient
            LinearGradient(gradient: Gradient(colors: [Color.white, Color.blue.opacity(0.1)]),
                           startPoint: .top, endPoint: .bottom)
                .ignoresSafeArea()

            ScrollView {
                VStack(alignment: .center, spacing: 20) {
                    // Exercise Image
                    Image(exercise.imageName)
                        .resizable()
                        .scaledToFill()
                        .frame(height: 200)
                        .clipped()
                        .cornerRadius(15)
                        .shadow(radius: 5)

                    // Title and Description
                    Text(exercise.name)
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(.blue)

                    Text(exercise.description)
                        .font(.headline)
                        .foregroundColor(.gray)

                    Divider()

                    // Timer Section
                    Text("Enter Workout Duration (in minutes)")
                        .font(.title3)
                        .foregroundColor(.secondary)

                    HStack(spacing: 10) {
                        TextField("e.g., 15", text: $duration)
                            .keyboardType(.numberPad)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .frame(width: 80)
                            .focused($isTextFieldFocused)

                        Button(action: startTimer) {
                            buttonLabel(text: "Start", color: .green, icon: "play.fill", size: 14)
                        }
                        .disabled(timerRunning)
                    }

                    // Timer Display
                    if timerRunning || timeRemaining > 0 {
                        Text("\(formatTime(timeRemaining))")
                            .font(.system(size: 40, weight: .bold))
                            .foregroundColor(.red)
                    }

                    if !timerRunning && timeRemaining > 0 {
                        // Calories Burned Section
                        let caloriesBurned = (elapsedTime / 60) * exercise.caloriesPerMinute
                        HStack {
                            Text("Calories Burned: \(caloriesBurned) kcal")
                                .font(.headline)
                                .foregroundColor(.orange)

                            Spacer()
                        }
                        .padding(.horizontal)
                    }

                    // Action Buttons
                    if timerRunning {
                        Button(action: stopTimer) {
                            buttonLabel(text: "Stop", color: .red, icon: "stop.fill", size: 14)
                        }
                    } else if timeRemaining > 0 {
                        HStack(spacing: 10) {
                            Button(action: resumeTimer) {
                                buttonLabel(text: "Resume", color: .orange, icon: "arrowtriangle.right.fill", size: 14)
                            }

                            Button(action: logExercise) {
                                buttonLabel(text: "Log", color: .blue, icon: "checkmark.circle.fill", size: 14)
                            }
                        }
                    }

                    Divider()

                    // Instructions
                    VStack(alignment: .leading, spacing: 8) {
                        Text("How to do this exercise:")
                            .font(.title2)
                            .fontWeight(.semibold)
                            .foregroundColor(.blue)

                        Text(exercise.instructions)
                            .font(.body)
                            .foregroundColor(.primary)
                            .multilineTextAlignment(.leading)
                    }
                    .padding(.horizontal)

                    Spacer()
                }
                .padding()
            }
            .onTapGesture { isTextFieldFocused = false }
        }
        .alert("Workout Complete", isPresented: $showCompletionAlert) {
            Button("OK", role: .cancel) { stopTimer() }
        } message: {
            Text("You have successfully completed \(exercise.name) for \(formatTime(elapsedTime)).")
        }
        .navigationBarTitleDisplayMode(.inline)
    }

    // MARK: - Timer Functions
    private func startTimer() {
        guard let minutes = Int(duration), minutes > 0 else { return }
        isTextFieldFocused = false
        timeRemaining = minutes * 60
        elapsedTime = 0
        timerRunning = true
        isPaused = false
        canLogExercise = false

        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            if timeRemaining > 0 {
                timeRemaining -= 1
                elapsedTime += 1
            } else {
                stopTimer()
                showCompletionAlert = true
            }
        }
    }

    private func stopTimer() {
        timer?.invalidate()
        timerRunning = false
        isPaused = true
        canLogExercise = true
    }

    private func resumeTimer() {
        guard isPaused else { return }
        timerRunning = true
        isPaused = false

        timer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { _ in
            if timeRemaining > 0 {
                timeRemaining -= 1
                elapsedTime += 1
            } else {
                stopTimer()
                showCompletionAlert = true
            }
        }
    }

    private func logExercise() {
        viewModel.addSession(exercise: exercise, duration: elapsedTime / 60)
        resetUI()
    }

    private func resetUI() {
        elapsedTime = 0
        timeRemaining = 0
        canLogExercise = false
        duration = ""
    }

    private func formatTime(_ seconds: Int) -> String {
        let minutes = seconds / 60
        let remainingSeconds = seconds % 60
        return String(format: "%02d:%02d", minutes, remainingSeconds)
    }

    // MARK: - Styled Button Label
    private func buttonLabel(text: String, color: Color, icon: String, size: CGFloat) -> some View {
        HStack {
            Image(systemName: icon)
                .foregroundColor(.white)
                .font(.system(size: size))
            Text(text)
                .foregroundColor(.white)
                .font(.system(size: size))
                .fontWeight(.semibold)
        }
        .padding(.vertical, 6)
        .padding(.horizontal, 12)
        .background(color)
        .cornerRadius(8)
        .shadow(color: color.opacity(0.4), radius: 5, x: 0, y: 2)
    }
}


