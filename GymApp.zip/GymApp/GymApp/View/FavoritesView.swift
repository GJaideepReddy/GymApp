//
//  FavoritesView.swift
//  GymApp
//
//  Created by Xcode on 12/10/24.
//

import SwiftUI

struct FavoritesView: View {
    @ObservedObject var viewModel: ExerciseViewModel

    var body: some View {
        ZStack {
            // Background color for a polished look
            LinearGradient(gradient: Gradient(colors: [Color.purple.opacity(0.3), Color.white]),
                           startPoint: .top,
                           endPoint: .bottom)
                .ignoresSafeArea()

            VStack {
                // Title Header
                Text("Your Favorite Exercises")
                    .font(.largeTitle)
                    .fontWeight(.bold)
                    .foregroundColor(.purple)
                    .padding(.top, 20)

                if viewModel.favorites.isEmpty {
                    // Empty State Message
                    VStack {
                        Image(systemName: "heart.slash")
                            .resizable()
                            .frame(width: 100, height: 100)
                            .foregroundColor(.gray)
                            .padding()
                        Text("No favorites added yet!")
                            .font(.title2)
                            .foregroundColor(.gray)
                    }
                    .padding()
                } else {
                    // Favorites List
                    ScrollView {
                        LazyVStack(spacing: 16) {
                            ForEach(viewModel.allExercises.filter { viewModel.isFavorite($0) }) { exercise in
                                HStack {
                                    NavigationLink(destination: ExerciseDetailView(exercise: exercise, viewModel: viewModel)) {
                                        HStack {
                                            Image(systemName: "star.circle.fill")
                                                .foregroundColor(.yellow)
                                                .font(.system(size: 40))
                                            VStack(alignment: .leading) {
                                                Text(exercise.name)
                                                    .font(.headline)
                                                    .foregroundColor(.black)
                                                Text(exercise.description)
                                                    .font(.subheadline)
                                                    .foregroundColor(.gray)
                                            }
                                            Spacer()
                                            Image(systemName: "chevron.right")
                                                .foregroundColor(.gray)
                                        }
                                    }
                                    .padding()
                                    .background(RoundedRectangle(cornerRadius: 12)
                                        .fill(Color.white)
                                        .shadow(color: .gray.opacity(0.4), radius: 4, x: 0, y: 2))
                                }
                            }
                        }
                        .padding(.horizontal)
                    }
                }
            }
        }
    }
}

#Preview {
    FavoritesView(viewModel: ExerciseViewModel())
}
