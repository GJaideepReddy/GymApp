//
//  ExerciseCard.swift
//  GymApp
//
//  Created by Xcode on 12/9/24.
//

import SwiftUI

struct ExerciseCard: View {
    let exercise: GymExercise
    let isFavorite: Bool
    let onFavoriteToggle: () -> Void

    var body: some View {
        HStack(alignment: .center, spacing: 12) {
            // Leading Icon/Image
            Image(systemName: "figure.walk") // Placeholder icon
                .font(.system(size: 40))
                .foregroundColor(.blue)
                .frame(width: 50, height: 50)
                .background(Color.blue.opacity(0.2))
                .clipShape(Circle())

            // Exercise Details
            VStack(alignment: .leading, spacing: 6) {
                Text(exercise.name)
                    .font(.headline)
                    .foregroundColor(.primary)

                Text(exercise.description)
                    .font(.subheadline)
                    .foregroundColor(.gray)
                    .lineLimit(2)

                // Additional Information: Calories and Difficulty
                HStack {
                    HStack(spacing: 4) {
                        Image(systemName: "flame.fill")
                            .foregroundColor(.red)
                        Text("\(exercise.caloriesPerMinute) kcal/min")
                            .font(.caption)
                            .foregroundColor(.secondary)
                    }

                    Spacer()

                    HStack(spacing: 4) {
                        Image(systemName: "chart.bar.fill")
                            .foregroundColor(.orange)
                        Text(exercise.difficulty.rawValue)
                            .font(.caption)
                            .foregroundColor(.secondary)
                            .lineLimit(1)
                            .minimumScaleFactor(0.5)
                    }
                }
            }

            Spacer()

            // Favorite Button
            Button(action: onFavoriteToggle) {
                Image(systemName: isFavorite ? "heart.fill" : "heart")
                    .foregroundColor(isFavorite ? .red : .gray)
                    .font(.system(size: 22))
            }
        }
        .padding()
        .background(
            RoundedRectangle(cornerRadius: 12)
                .fill(Color.white)
                .shadow(color: Color.gray.opacity(0.3), radius: 4, x: 0, y: 2)
        )
    }
}

/*#Preview {
    ExerciseCard(exercise: GymExercise(name: "Push-Ups", description: "Strengthens chest and arms.", imageName: "pushup", instructions: "Lower your body and push back up.", caloriesPerMinute: 8, difficulty: .Beginner), isFavorite: "Bool") {
        <#code#>
    }
}
*/
