//
//  KeyboardDismissHelper.swift
//  GymApp
//
//  Created by Xcode on 12/10/24.
//

import SwiftUI

import SwiftUI

extension UIApplication {
    static func dismissKeyboard() {
        // Send action to resign the first responder and dismiss the keyboard
        self.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}



