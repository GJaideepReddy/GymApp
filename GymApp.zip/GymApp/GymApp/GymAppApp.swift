//
//  GymAppApp.swift
//  GymApp
//
//  Created by Xcode on 12/9/24.
//

import SwiftUI

@main
struct GymAppApp: App {
    var body: some Scene {
        WindowGroup {
            ExerciseView()
        }
    }
}
