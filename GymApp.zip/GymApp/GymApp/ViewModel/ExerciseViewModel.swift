//
//  ExerciseViewModel.swift
//  GymApp
//
//  Created by Xcode on 12/9/24.
//

import Foundation
import Combine



// MARK: - ViewModel
class ExerciseViewModel: ObservableObject {
    @Published var allExercises: [GymExercise] = []
    @Published var favorites: [UUID] = []
    @Published var exerciseSessions: [ExerciseSession] = []
    @Published var calorieGoal: Int = 500
    @Published var totalCaloriesBurnt: Int = 0
    
    private let favoritesKey = "favorites"
    private let sessionsKey = "exerciseSessions"
    private let goalKey = "calorieGoal"
    
    init() {
        loadFavorites()
        loadSessions()
        loadGoal()
        calculateTotalCalories()
        fetchExercises()
    }
    
    // MARK: - Fetch Exercises
    func fetchExercises() {
        allExercises = [
            GymExercise(
                name: "Push-Ups",
                description: "Strengthens chest and arms.",
                imageName: "pushup",
                instructions: "Lower your body and push back up.",
                caloriesPerMinute: 8,
                difficulty: .Beginner
            ),
            GymExercise(
                name: "Burpees",
                description: "Full-body cardio exercise.",
                imageName: "burpees",
                instructions: "Squat, plank, push-up, jump, and repeat.",
                caloriesPerMinute: 12,
                difficulty: .Advanced
            ),
            GymExercise(
                name: "Plank",
                description: "Improves core strength.",
                imageName: "plank",
                instructions: "Hold your body straight in plank position.",
                caloriesPerMinute: 5,
                difficulty: .Intermediate
            ),
            GymExercise(
                name: "Jumping Jacks",
                description: "Improves cardiovascular fitness.",
                imageName: "jumping_jacks",
                instructions: "Jump while spreading your legs and arms, then return.",
                caloriesPerMinute: 10,
                difficulty: .Beginner
            ),
            GymExercise(
                name: "Mountain Climbers",
                description: "Core and cardio workout.",
                imageName: "mountain_climbers",
                instructions: "Start in plank, bring knees toward chest alternately.",
                caloriesPerMinute: 11,
                difficulty: .Intermediate
            ),
            GymExercise(
                name: "Squats",
                description: "Strengthens lower body and glutes.",
                imageName: "squats",
                instructions: "Lower hips, keep chest upright, and return.",
                caloriesPerMinute: 7,
                difficulty: .Beginner
            ),
            GymExercise(
                name: "Lunges",
                description: "Improves balance and strengthens legs.",
                imageName: "lunges",
                instructions: "Step forward, lower knee, and alternate legs.",
                caloriesPerMinute: 8,
                difficulty: .Intermediate
            ),
            GymExercise(
                name: "High Knees",
                description: "Full-body cardio workout.",
                imageName: "high_knees",
                instructions: "Run in place, lifting knees as high as possible.",
                caloriesPerMinute: 14,
                difficulty: .Advanced
            )
        ]
    }
    
    // MARK: - Favorites Management
    func isFavorite(_ exercise: GymExercise) -> Bool {
        favorites.contains(exercise.id)
    }
    
    func toggleFavorite(_ exercise: GymExercise) {
        if let index = favorites.firstIndex(of: exercise.id) {
            favorites.remove(at: index)
        } else {
            favorites.append(exercise.id)
        }
        saveFavorites()
    }
    
    private func saveFavorites() {
        let favoriteIDs = favorites.map { $0.uuidString }
        UserDefaults.standard.set(favoriteIDs, forKey: favoritesKey)
    }
    
    private func loadFavorites() {
        if let savedFavorites = UserDefaults.standard.array(forKey: favoritesKey) as? [String] {
            favorites = savedFavorites.compactMap { UUID(uuidString: $0) }
        }
    }
    
    // MARK: - Exercise Sessions Management
    func addSession(exercise: GymExercise, duration: Int) {
        let caloriesBurnt = exercise.caloriesPerMinute * duration
        let session = ExerciseSession(
            id: UUID(),
            exerciseName: exercise.name,
            duration: duration,
            caloriesBurnt: caloriesBurnt,
            date: Date()
        )
        exerciseSessions.append(session)
        calculateTotalCalories()
        saveSessions()
    }
    
    private func saveSessions() {
        if let encoded = try? JSONEncoder().encode(exerciseSessions) {
            UserDefaults.standard.set(encoded, forKey: sessionsKey)
        }
    }
    
    private func loadSessions() {
        if let data = UserDefaults.standard.data(forKey: sessionsKey),
           let decodedSessions = try? JSONDecoder().decode([ExerciseSession].self, from: data) {
            exerciseSessions = decodedSessions
        }
    }
    
    // MARK: - Calorie Goal Management
    func setCalorieGoal(_ goal: Int) {
        calorieGoal = goal
        saveGoal()
    }
    
    func resetGoalToZero() {
        calorieGoal = 0
        exerciseSessions.removeAll()
        totalCaloriesBurnt = 0
        saveGoal()
        saveSessions()
    }
    
    private func saveGoal() {
        UserDefaults.standard.set(calorieGoal, forKey: goalKey)
    }
    
    private func loadGoal() {
        calorieGoal = UserDefaults.standard.integer(forKey: goalKey)
    }
    
    func calculateTotalCalories() {
        totalCaloriesBurnt = exerciseSessions.reduce(0) { $0 + $1.caloriesBurnt }
    }
}
